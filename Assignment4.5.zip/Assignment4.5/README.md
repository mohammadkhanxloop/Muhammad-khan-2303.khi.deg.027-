# Descrepition

## Assignment4.5

Based on the solution from day 1 (/tasks/5_microservices_development/day_1_microservices/integrating_flask_redis/) add Redis as another ECS service and connect it with existing application. Incorporate results from function get_and_increase_hit_count() into the application and show the results on the
main page.

### Team Members 
1. Mehboob ali
2. Ali Umair
3. Muhammad Khan
