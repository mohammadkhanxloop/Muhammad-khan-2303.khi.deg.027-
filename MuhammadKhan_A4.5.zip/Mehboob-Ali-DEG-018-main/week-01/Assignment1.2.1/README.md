# Mehboob-Ali-DEG-018

### Assignment 2
#### Description
Write a dataclass describing a mountain (containing fields for name and elevation) and:
- Construct an instance of the dataclass
- Convert it to string
