# Mehboob-Ali-DEG-018

### Assignment 2.1
#### Description
Create a new SQLFiddle and then add the database from db.sql (provided in tasks/1_introduction/day_2_basic_tooling/hands_on_sql) to be able to perform queries.


Your task then is to do two things:
1. Insert two articles written by Joe (id 3) into articles table (choosing the titles is up to you).
2. Write a query that will return you a list of articles written by authors who are at least 25 years old.
