# Mehboob-Ali-DEG-018

### Assignment 3
#### Description
1.Create a new git repository in a local directory.
2.Create an empty file “numbers.txt” and commit it to the current (“main” or “master”) branch.
3.Create two new branches: “odd” and “even”.
4.Switch to the “odd” branch.
5.Edit the “numbers.txt” file by adding some odd numbers, then commit the change.
6.Switch to the “even” branch.
7.Edit the “numbers.txt” file by adding some even numbers, then commit the change.
8.Switch to the main branch.
9.Merge the “odd” branch to the current one.
10.Try to merge the “even” branch too – it should cause a conflict.
11.Resolve the conflict by combining all the numbers and commit the merge.

List the commits using git log -p command and save the output in a file.


### Team Members 
1. Mehboob Ali
2. Ali Umair
3. Muzammil Mehmood 
