# Mehboob-Ali-DEG-018

### Assignment 4
#### Description

●Build an image based on Jupyter Notebook (jupyter/minimal-notebook) with Pandas installed (pip install pandas)
●Create a container from this image and use the NOTEBOOK_ARGS=--port=8889 environment variable to change the port Jupyter is exposed on
●Verify you can access it on port 8889 and that Pandas is installed (type import pandas in a notebook).

### Team Members 
1. Mehboob Ali
2. Ali Umair
