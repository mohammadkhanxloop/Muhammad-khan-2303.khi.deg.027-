# Mehboob-Ali-DEG-018


### Assignment 1 

#### Description
On a linux server setup a cron job for copying example data with rsync periodically.

Ensure the copying is handled in the background and independently of the user session.
