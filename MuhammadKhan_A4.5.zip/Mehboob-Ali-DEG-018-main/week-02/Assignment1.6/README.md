#Description

## Assignment 1.6

Draw a UML state diagram of a mobile phone.

At minimum, it must contain the following states:

●Off
●Idle
●Active
●Ringing
●Call
●texting



## Team Members
1. Mehboob ali
2. Ali Umair
