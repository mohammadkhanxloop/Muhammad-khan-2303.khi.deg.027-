# Assignment 2.1

## Description

Write a bash command which Write a bash command which formats markdown cells in file my_notebook.ipynb (using github page of nbqa)


### Team Members 
1. Mehboob Ali
2. Ali Umair

