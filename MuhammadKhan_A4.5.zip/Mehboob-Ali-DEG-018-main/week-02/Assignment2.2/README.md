# Description

## Assignment 2.2

Build a 6x4 matrix of random numbers.

Using slicing, replace rows 5-6 of the matrix so that the 5th row becomes a sum of the 1st and the 3rd row, and the 6th row becomes a sum of the 2nd and the 4th one



### Team Members 
1. Mehboob Ali
2. Ali Umair 
