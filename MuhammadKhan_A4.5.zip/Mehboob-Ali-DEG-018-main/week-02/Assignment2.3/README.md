# Description

## Assignment 2.3

Download the Iris dataset from kaggle and 
Write a program that loads a CSV file and answers,

What is the average Sepal Length for each of three iris species?


### Team Members
1. Mehboob Ali
2. Ali Umair
