# Description

## Assignment3.4

1. A

Write a component that will log metadata of your
Classification model that you trained on the day dedicated to
Supervised Learning. Remember to include all metadata that
are important to track for this problem.

2. B

Write a component that will log metadata of your
Classification model that you trained on the day dedicated to
Supervised Learning. Remember to include all metadata that
are important to track for this problem.

### Team Members
1. Mehboob Ali
2. Ali Umair 
