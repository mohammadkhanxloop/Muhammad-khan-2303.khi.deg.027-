#!/bin/sh

export MLFLOW_CONDA_HOME=/home/mehboobali/miniconda3/
export MLFLOW_TRACKING_URI="http://0.0.0.0:5000"
export MLFLOW_AR=./mlruns
