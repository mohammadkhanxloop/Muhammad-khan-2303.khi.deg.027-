# Description

## Assignment 2.4

Download the Breast Cancer Wisconsin dataset from
https://www.kaggle.com/datasets/uciml/breast-cancer-wisconsin-data

After downloading, read about scatter matrix and implement it using plotly.
Limit it to only few (5-6) features of your choice. Try to make it as readable
as possible (eg. use colors to represent target class).


### Team Members
1. Mehboob Ali
2. Ali Umair 
