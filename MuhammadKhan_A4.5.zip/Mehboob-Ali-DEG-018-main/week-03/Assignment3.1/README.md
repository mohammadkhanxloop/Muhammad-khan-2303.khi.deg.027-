# Description

## Assignment 3.1

Implement a label encoder for categorical data
using pure Python, Pandas and NumPy.


### Team Members
1. Mehboob Ali
2. Ali Umair 
