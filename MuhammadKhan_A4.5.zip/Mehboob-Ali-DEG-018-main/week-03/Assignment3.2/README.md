# Description

## Assignment3.2

Implement a single classification model of your choice and try
to achieve at least an 80% F1 score on the wine dataset
provided by Sklearn.

### Team Members
1. Mehboob Ali
2. Ali Umair 
