# Description

## Assignment3.3

Perform k-means clusterization on the Iris
dataset. Repeat the procedure on the
dataset reduced with PCA, and then
compare the results.


### Team Members
1. Mehboob Ali
2. Ali Umair 
