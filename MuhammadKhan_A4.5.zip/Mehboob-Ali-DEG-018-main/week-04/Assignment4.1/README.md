# Description

## Assignment3.5

Browse to:
tasks/4_microservices_development/day_1_microservices/doc
ker_compose_example
Next you will:
  - Start the system using docker-compose so that it runs in
background.
  - Visit http://127.0.0.1/ to see WordPress installation panel,
  - See the system logs
  - Add a PHPMyAdmin service from
https://hub.docker.com/r/phpmyadmin/phpmyadmin/ so that
you can manage the raw database contents.


### Team Members
1. Mehboob Ali
2. Ali Umair 
