# Description

## Assignment4.2

Start Kafka using docker-compose and:
1. Create a topic.
2. List Kafka topics.
3. Inspect one of them to see the number of partitions.

### Team Members
1. Mehboob Ali
2. Ali Umair 
