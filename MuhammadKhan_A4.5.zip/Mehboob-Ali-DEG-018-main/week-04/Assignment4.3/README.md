# Description

## Assignment4.3

Display logs of a running MongoDB container. Add a document to the DB via Mongo Express frontend. Get into the pod and verify the document's existence via mongosh.

### Team Members
1. Mehboob Ali
2. Ali Umair 
