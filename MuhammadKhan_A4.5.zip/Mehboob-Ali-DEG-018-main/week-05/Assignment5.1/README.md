# Descrepition

## Assignment5.1

Based on the data contained in 
tasks/4_data_pipelines/day_1_introduction/daily_assignment/data 
directory, use PySpark to read, filter and join the data from CSV files and answer the following questions:

What are the daily total sales for the store with id 1?

What are the mean sales for the store with id 2?

What is the email of the client who spent the most when summing up purchases from all of the stores?

Which 5 products are most frequently bought across all stores?

### Team Members 
1. Mehboob ali
2. Ali Umair
3. Muhammad Khan
